Remove-Item C:\\inetpub\\wwwroot\\index.html
